
# Render / Replit 入口 - 同 tg_bot_sample.py 一樣，但加咗 web server 保活
import os, threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from dotenv import load_dotenv
load_dotenv()

# 保活用的簡易 web server，俾 UptimeRobot ping
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"CW Bot is alive")

def run_web():
    port = int(os.environ.get("PORT", 10000))
    HTTPServer(("0.0.0.0", port), Handler).serve_forever()

threading.Thread(target=run_web, daemon=True).start()

# 啟動 Telegram Bot
import tg_bot_sample
# tg_bot_sample 會自己 run_polling
